/*
 * Created on 26.06.2005
 */
package org.tmatesoft.svn.core.client;

import org.tigris.subversion.javahl.ClientException;
import org.tigris.subversion.javahl.SVNClientInterface;

public interface ISVNClientInterfaceEx extends SVNClientInterface {
    
    public void move(String srcPath, String dstPath, boolean force) throws ClientException;

    public boolean isCredentialsCacheEnabled();

    public void setCredentialsCacheEnabled(boolean cacheCredentials);

    public boolean isSSLCertificateCacheEnabled();

    public void setSSLCertificateCacheEnabled(boolean enabled);

    public void setTouchUnresolved(boolean touchUnresolved);
    
    public boolean isTouchUnresolved();

    public void setCommitMissedFiles(boolean commitMissingFiles);
    
    public boolean isCommitMissingFile();
    
    public void setClientSSLCertificate(String certPath, String passphrase);
    
    public void setSSHCredentials(String userName, String privateKeyPath, String passphrase, int port);

    public void setSSHCredentials(String userName, String password, int port);

    public void setProxy(String host, int port, String userName, String password);
}
