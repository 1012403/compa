/*
 * ====================================================================
 * Copyright (c) 2004-2006 TMate Software Ltd.  All rights reserved.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution.  The terms
 * are also available at http://tmate.org/svn/license.html.
 * If newer versions of this license are posted there, you may use a
 * newer version instead, at your option.
 * ====================================================================
 */
package org.tmatesoft.svn.core.auth;

public class SVNProxyAuthentication extends SVNAuthentication {

    private String myPassword;
    private String myHost;
    private int myPort;

    public SVNProxyAuthentication(String userName, String password, String host, int port, boolean storageAllowed) {
        super(ISVNAuthenticationManager.PROXY, userName, storageAllowed);
        myPassword = password;
        myHost = host;
        myPort = port >= 0 ? port : 3128;
    }
    
    public String getPassword() {
        return myPassword;
    }
    
    public String getHost() {
        return myHost;
    }

    public int getPort() {
        return myPort;
    }
}
