/*
 * Created on 26.06.2005
 */
package org.tmatesoft.svn.core.client;

import java.io.File;

import org.tigris.subversion.javahl.ClientException;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.javahl.SVNClientImpl;
import org.tmatesoft.svn.core.wc.DefaultSVNCommitParameters;
import org.tmatesoft.svn.core.wc.SVNMoveClient;


public class SVNClientEx extends SVNClientImpl implements ISVNClientInterfaceEx {
    private boolean myIsTouchUnresolved;
    private boolean myIsCommitMissingFiles;
    private String myProxyPassword;
    private String myProxyUserName;
    private int myProxyPort;
    private String myProxyHost;
    private int mySSHPort;
    private String mySSHUserName;
    private String mySSHPassphrase;
    private String mySSHKeyPath;
    private String mySSLPassphrase;
    private String mySSLCertPath;
    private String mySSH2Password;
    private String mySSH2UserName;
    private int mySSH2Port;

    public SVNClientEx() {
        super(null);
        setTouchUnresolved(true);
    }
    
    public void setTouchUnresolved(boolean touchUnresolved) {
        myIsTouchUnresolved = touchUnresolved;
        getSVNUpdateClient().setLeaveConflictsUnresolved(!touchUnresolved);
        getSVNCopyClient().setLeaveConflictsUnresolved(!touchUnresolved);
        getSVNDiffClient().setLeaveConflictsUnresolved(!touchUnresolved);
    }
    
    public boolean isTouchUnresolved() {
        return myIsTouchUnresolved;
    }

    public void setCommitMissedFiles(boolean commitMissingFiles) {
        myIsCommitMissingFiles = commitMissingFiles;
        DefaultSVNCommitParameters params = new DefaultSVNCommitParameters() {
            public Action onMissingFile(File file) {
                return myIsCommitMissingFiles ? DELETE : SKIP;
            }
            public Action onMissingDirectory(File file) {
                return myIsCommitMissingFiles ? DELETE : ERROR;
            }
        };
    	getSVNCommitClient().setCommitParameters(params);
    	getSVNCopyClient().setCommitParameters(params);
    }

    public boolean isCommitMissingFile() {
        return myIsCommitMissingFiles;
    }

    public void setClientSSLCertificate(String certPath, String passphrase) {
        mySSLCertPath = certPath;
        mySSLPassphrase = passphrase;
        updateClientManager();
    }

    public void setSSHCredentials(String userName, String privateKeyPath, String passphrase, int port) {
        mySSHKeyPath = privateKeyPath;
        mySSHPassphrase = passphrase;
        mySSHUserName = userName;
        mySSHPort = port;
        updateClientManager();
    }

    public void setSSHCredentials(String userName, String password, int port) {
        mySSH2Password = password;
        mySSH2UserName = userName;
        mySSH2Port = port;
        updateClientManager();
    }

    public void setProxy(String host, int port, String userName, String password) {
        myProxyHost = host;
        myProxyPort = port;
        myProxyUserName = userName;
        myProxyPassword = password;
        updateClientManager();
    }

    public void move(String srcPath, String dstPath, boolean force) throws ClientException {
        SVNMoveClient client = getClientManager().getMoveClient();
        try {
            if(!isURL(srcPath) && !isURL(dstPath)){
                client.doMove(new File(srcPath), new File(dstPath));
            }
        } catch (SVNException e) {
            throwException(e);
        }
    }

    protected ISVNAuthenticationManager createAuthenticationManager(File configDir, String userName, String password, boolean allowSave, boolean saveSSL) {
        SVNClientAuthenticationManager authManager = new SVNClientAuthenticationManager(configDir, allowSave, saveSSL, userName, password);
        authManager.setProxy(myProxyHost, myProxyPort, myProxyUserName, myProxyPassword);
        authManager.setClientSSLCertificate(mySSLCertPath, mySSLPassphrase);
        authManager.setSSHCredentials(mySSHUserName, mySSHKeyPath, mySSHPassphrase, mySSHPort);
        authManager.setSSHCredentials(mySSH2UserName, mySSH2Password, mySSH2Port);
        return authManager;
    }
}

    
