/*******************************************************************************
 * Copyright (c) 2005-2008 Polarion Software.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Alexander Gurov - Initial API and implementation
 *    Pavel Zuev - [patch] peg revisions for compare operation
 *    Micha Riser - [patch] JavaHLConnector creates a huge amount of short living threads
 *******************************************************************************/

package org.polarion.team.svn.connector.javahl;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.team.svn.core.connector.ISVNAnnotationCallback;
import org.eclipse.team.svn.core.connector.ISVNChangeListCallback;
import org.eclipse.team.svn.core.connector.ISVNConflictResolutionCallback;
import org.eclipse.team.svn.core.connector.ISVNConnector;
import org.eclipse.team.svn.core.connector.ISVNCredentialsPrompt;
import org.eclipse.team.svn.core.connector.ISVNDiffStatusCallback;
import org.eclipse.team.svn.core.connector.ISVNEntryCallback;
import org.eclipse.team.svn.core.connector.ISVNEntryInfoCallback;
import org.eclipse.team.svn.core.connector.ISVNEntryStatusCallback;
import org.eclipse.team.svn.core.connector.ISVNLogEntryCallback;
import org.eclipse.team.svn.core.connector.ISVNMergeStatusCallback;
import org.eclipse.team.svn.core.connector.ISVNNotificationCallback;
import org.eclipse.team.svn.core.connector.ISVNProgressMonitor;
import org.eclipse.team.svn.core.connector.ISVNPropertyCallback;
import org.eclipse.team.svn.core.connector.SVNConnectorAuthenticationException;
import org.eclipse.team.svn.core.connector.SVNConnectorCancelException;
import org.eclipse.team.svn.core.connector.SVNConnectorException;
import org.eclipse.team.svn.core.connector.SVNConnectorUnresolvedConflictException;
import org.eclipse.team.svn.core.connector.SVNDiffStatus;
import org.eclipse.team.svn.core.connector.SVNEntry;
import org.eclipse.team.svn.core.connector.SVNEntryInfo;
import org.eclipse.team.svn.core.connector.SVNEntryReference;
import org.eclipse.team.svn.core.connector.SVNEntryRevisionReference;
import org.eclipse.team.svn.core.connector.SVNErrorCodes;
import org.eclipse.team.svn.core.connector.SVNLogEntry;
import org.eclipse.team.svn.core.connector.SVNLogPath;
import org.eclipse.team.svn.core.connector.SVNMergeInfo;
import org.eclipse.team.svn.core.connector.SVNMergeStatus;
import org.eclipse.team.svn.core.connector.SVNNotification;
import org.eclipse.team.svn.core.connector.SVNProperty;
import org.eclipse.team.svn.core.connector.SVNRevision;
import org.eclipse.team.svn.core.connector.SVNRevisionRange;
import org.eclipse.team.svn.core.utility.Notify2Composite;
import org.eclipse.team.svn.core.utility.SVNUtility;
import org.tigris.subversion.javahl.ChangelistCallback;
import org.tigris.subversion.javahl.ClientException;
import org.tigris.subversion.javahl.ConversionUtility;
import org.tigris.subversion.javahl.CopySource;
import org.tigris.subversion.javahl.DiffSummary;
import org.tigris.subversion.javahl.DiffSummaryReceiver;
import org.tigris.subversion.javahl.ListCallback;
import org.tigris.subversion.javahl.Lock;
import org.tigris.subversion.javahl.LogMessageCallback;
import org.tigris.subversion.javahl.PromptUserPassword3;
import org.tigris.subversion.javahl.Revision;
import org.tigris.subversion.javahl.SVNAdmin;
import org.tigris.subversion.javahl.SVNClient;
import org.tigris.subversion.javahl.Status;
import org.tigris.subversion.javahl.StatusCallback;
import org.tigris.subversion.javahl.SubversionException;

/**
 * Native connector library wrapper.
 * 
 * @author Alexander Gurov
 */
public class JavaHLConnector implements ISVNConnector {
	protected static ProgressMonitorThread monitorWrapperThread;

	protected SVNAdmin svnAdmin;
	protected SVNClient client;
	protected ISVNCredentialsPrompt prompt;
	protected Notify2Composite composite;
	protected ISVNNotificationCallback installedNotify2;
	protected boolean commitMissingFiles;
	
	protected String sslCertificate;
	protected String sslPassphrase;

	public JavaHLConnector() {
		this.client = new SVNClient();
		this.client.notification2(ConversionUtility.convert(this.composite = new Notify2Composite()));
		this.svnAdmin = new SVNAdmin();
	}

	public String getConfigDirectory() throws SVNConnectorException {
		try {
			return this.client.getConfigDirectory();
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		// unreachable code
		return null;
	}
	
	public void setConfigDirectory(String configDir) throws SVNConnectorException {
		try {
			this.client.setConfigDirectory(configDir);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
	}
	
	
	public void setUsername(String username) {
		this.client.username(username == null ? "" : username);
	}

	public void setPassword(String password) {
		this.client.password(password == null ? "" : password);
	}

	public boolean isCredentialsCacheEnabled() {
		return true;
	}

	public void setCredentialsCacheEnabled(boolean cacheCredentials) {
		// credentials cache is always enabled for native connector
	}

	public void setPrompt(ISVNCredentialsPrompt prompt) {
		this.client.setPrompt(prompt == null ? null : new RepositoryInfoPrompt(this.prompt = prompt));
	}

	public ISVNCredentialsPrompt getPrompt() {
		return this.prompt;
	}

	public void setProxy(String host, int port, String userName, String password) {
		// never works for native connector

	}

	public void setClientSSLCertificate(String certPath, String passphrase) {
		this.sslCertificate = certPath == null || certPath.trim().length() == 0 ? null : certPath;
		this.sslPassphrase = passphrase;
	}

	public boolean isSSLCertificateCacheEnabled() {
		return true;
	}

	public void setSSLCertificateCacheEnabled(boolean enabled) {
		// SSL certificate cache is always enabled for native connector
	}

	public void setSSHCredentials(String userName, String privateKeyPath, String passphrase, int port) {
		// never works for native connector

	}

	public void setSSHCredentials(String userName, String password, int port) {
		// never works for native connector

	}

	
	public void setCommitMissingFiles(boolean commitMissingFiles) {
		this.commitMissingFiles = commitMissingFiles;
	}

	public boolean isCommitMissingFiles() {
		return this.commitMissingFiles;
	}

	public void setTouchUnresolved(boolean touchUnresolved) {
		// native connector always merges conflicing resources
	}

	public boolean isTouchUnresolved() {
		return true;
	}
	
	public void setNotificationCallback(ISVNNotificationCallback notify) {
		if (this.installedNotify2 != null) {
			this.composite.remove(this.installedNotify2);
		}
		this.installedNotify2 = notify;
		if (this.installedNotify2 != null) {
			this.composite.add(this.installedNotify2);
		}
	}

	public ISVNNotificationCallback getNotificationCallback() {
		return this.installedNotify2;
	}


	public long checkout(SVNEntryRevisionReference fromReference, String destPath, int depth, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			return this.client.checkout(fromReference.path, destPath, ConversionUtility.convert(fromReference.revision), ConversionUtility.convert(fromReference.pegRevision), depth, (options & Options.IGNORE_EXTERNALS) != 0, (options & Options.ALLOW_UNVERSIONED_OBSTRUCTIONS) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return 0;
	}

	public void lock(String[] path, String comment, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.lock(path, comment, (options & Options.FORCE) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void unlock(String[] path, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.unlock(path, (options & Options.FORCE) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void add(String path, int depth, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.add(path, depth, (options & Options.FORCE) != 0, (options & Options.INCLUDE_IGNORED) != 0, (options & Options.INCLUDE_PARENTS) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public long[] commit(String []path, String message, String[] changelistNames, int depth, long options, Map revProps, ISVNProgressMonitor monitor) throws SVNConnectorException {
		boolean noUnlock = (options & Options.KEEP_LOCKS) != 0;
		boolean keepChangelist = (options & Options.KEEP_CHANGE_LIST) != 0;
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			if (this.commitMissingFiles) {
				for (int i = 0; i < path.length && !monitor.isActivityCancelled(); i++) {
					if (!new File(path[i]).exists()) {
						this.client.remove(new String[] {path[i]}, null, true, false, null);
					}
				}
			}
			
			if (depth != Depth.INFINITY) {
				HashSet<String> fullSet = new HashSet<String>(Arrays.asList(path));
				HashSet<String> deleted = new HashSet<String>();
				Arrays.sort(path);
				for (int i = 0; i < path.length && !monitor.isActivityCancelled(); i++) {
					File toCheck = new File(path[i]);
					if (toCheck.isDirectory()) {
						final org.tigris.subversion.javahl.Status []st = new org.tigris.subversion.javahl.Status[1];
						this.client.status(path[i], Depth.EMPTY, false, false, false, false, null, new StatusCallback() {
							public void doStatus(Status status) {
								st[0] = status;
							}
						});
						if (st[0] != null && st[0].getTextStatus() == org.tigris.subversion.javahl.StatusKind.deleted) {
							deleted.add(path[i]);
							String root = path[i];
							while (i < path.length && !monitor.isActivityCancelled()) {
								if (path[i].startsWith(root) && (path[i].length() == root.length() || path[i].charAt(root.length()) == '\\' || path[i].charAt(root.length()) == '/')) {
									fullSet.remove(path[i]);
									i++;
								}
								else {
									i--;
									break;
								}
							}
						}
					}
				}
				if (deleted.size() > 0) {
					if (fullSet.size() == 0) {
						path = deleted.toArray(new String[deleted.size()]);
						depth = Depth.INFINITY;
					}
					else {
						path = fullSet.toArray(new String[fullSet.size()]);
						String []deletedPath = deleted.toArray(new String[deleted.size()]);
						
						this.composite.add(wrapper);
						wrapper.start();
						return new long[] {
								this.client.commit(path, message, depth, noUnlock, keepChangelist, changelistNames, ConversionUtility.convert(revProps)),
								this.client.commit(deletedPath, message, Depth.INFINITY, noUnlock, keepChangelist, changelistNames, ConversionUtility.convert(revProps)),
						};
					}
				}
			}
			
			this.composite.add(wrapper);
			wrapper.start();
			return new long[] {this.client.commit(path, message, depth, noUnlock, keepChangelist, changelistNames, ConversionUtility.convert(revProps))};
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return null;
	}
	
	public long[] update(String []path, SVNRevision revision, int depth, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			return this.client.update(path, ConversionUtility.convert(revision), depth, (options & Options.DEPTH_IS_STICKY) != 0, (options & Options.IGNORE_EXTERNALS) != 0, (options & Options.ALLOW_UNVERSIONED_OBSTRUCTIONS) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return null;
	}

	public long doSwitch(String path, SVNEntryRevisionReference toReference, int depth, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			return this.client.doSwitch(path, toReference.path, ConversionUtility.convert(toReference.revision), ConversionUtility.convert(toReference.pegRevision), depth, (options & Options.DEPTH_IS_STICKY) != 0, (options & Options.IGNORE_EXTERNALS) != 0, (options & Options.ALLOW_UNVERSIONED_OBSTRUCTIONS) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return 0;
	}

	public void revert(String path, int depth, String[] changelistNames, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			// FIXME replaced/prereplaced files cannot be reverted ???
			this.client.revert(path, depth, changelistNames);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void status(String path, int depth, long options, String[] changelistNames, ISVNEntryStatusCallback callback, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.status(path, depth, (options & Options.SERVER_SIDE) != 0, (options & Options.INCLUDE_UNCHANGED) != 0, (options & Options.INCLUDE_IGNORED) != 0, (options & Options.IGNORE_EXTERNALS) != 0, changelistNames, ConversionUtility.convert(callback));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void relocate(String from, String to, String path, int depth, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.relocate(from, to, path, depth == Depth.INFINITY);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void cleanup(String path, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.cleanup(path);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void merge(SVNEntryRevisionReference reference1, SVNEntryRevisionReference reference2, String localPath, int depth, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.merge(reference1.path, ConversionUtility.convert(reference1.revision), reference2.path, ConversionUtility.convert(reference2.revision), localPath, (options & Options.FORCE) != 0, depth, (options & Options.IGNORE_ANCESTRY) != 0, (options & Options.SIMULATE) != 0, (options & Options.RECORD_ONLY) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public void merge(SVNEntryReference reference, SVNRevisionRange []revisions, String localPath, int depth, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.merge(reference.path, ConversionUtility.convert(reference.pegRevision), ConversionUtility.convert(revisions), localPath, (options & Options.FORCE) != 0, depth, (options & Options.IGNORE_ANCESTRY) != 0, (options & Options.SIMULATE) != 0, (options & Options.RECORD_ONLY) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public void mergeReintegrate(SVNEntryReference reference, String localPath, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.mergeReintegrate(reference.path, ConversionUtility.convert(reference.pegRevision), localPath, (options & Options.SIMULATE) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public SVNMergeInfo getMergeInfo(SVNEntryReference reference, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			return ConversionUtility.convert(this.client.getMergeinfo(reference.path, ConversionUtility.convert(reference.pegRevision)));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		catch (SubversionException ex) {
			this.handleSubversionException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return null;
	}

    public void getMergeInfoLog(int logKind, SVNEntryReference reference, SVNEntryReference mergeSourceReference, String[] revProps, long options, ISVNLogEntryCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.getMergeinfoLog(logKind, reference.path, ConversionUtility.convert(reference.pegRevision), mergeSourceReference.path, ConversionUtility.convert(mergeSourceReference.pegRevision), (options & Options.DISCOVER_PATHS) != 0, revProps, ConversionUtility.convert(cb));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
    }
    
	public String []suggestMergeSources(SVNEntryReference reference, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			return this.client.suggestMergeSources(reference.path, ConversionUtility.convert(reference.pegRevision));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		catch (SubversionException ex) {
			this.handleSubversionException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return null;
	}

	public void resolve(String path, int conflictResult, int depth, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.resolve(path, depth, conflictResult);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		catch (SubversionException ex) {
			this.handleSubversionException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public void setConflictResolver(ISVNConflictResolutionCallback listener) {
		this.client.setConflictResolver(ConversionUtility.convert(listener));
	}
	
    public void addToChangeList(String[] paths, String changelist, int depth, String[] changelistNames, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.addToChangelist(paths, changelist, depth, changelistNames);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
    }
    
    public void removeFromChangeLists(String[] paths, int depth, String[] changelistNames, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.removeFromChangelists(paths, depth, changelistNames);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
    }
    
    public void dumpChangeLists(String[] changeLists, String rootPath, int depth, final ISVNChangeListCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.getChangelists(rootPath, changeLists, depth, new ChangelistCallback() {
				public void doChangelist(String path, String changelist) {
					cb.next(path, changelist);
				}
			});
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
    }

    
	public void merge(SVNEntryReference reference, SVNRevisionRange []revisions, String mergePath, SVNMergeStatus[] mergeStatus, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		this.merge(reference, null, revisions, mergePath, mergeStatus, options, monitor);
	}

	public void merge(SVNEntryRevisionReference reference1, SVNEntryRevisionReference reference2, String mergePath, SVNMergeStatus[] mergeStatus, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		this.merge(reference1, reference2, null, mergePath, mergeStatus, options, monitor);
	}
	
	public void mergeStatus(SVNEntryReference reference, SVNRevisionRange []revisions, String path, int depth, long options, ISVNMergeStatusCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		this.mergeStatus(reference, null, revisions, path, depth, options, cb, monitor);
	}

	public void mergeStatus(SVNEntryRevisionReference reference1, SVNEntryRevisionReference reference2, String path, int depth, long options, ISVNMergeStatusCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		this.mergeStatus(reference1, reference2, null, path, depth, options, cb, monitor);
	}
	
	public void merge(SVNEntryReference reference, String mergePath, SVNMergeStatus[] mergeStatus, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		this.merge(reference, null, null, mergePath, mergeStatus, options, monitor);
	}

	public void mergeStatus(SVNEntryReference reference, String mergePath, long options, ISVNMergeStatusCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		this.mergeStatus(reference, null, null, mergePath, ISVNConnector.Depth.INFINITY, options, cb, monitor);
	}

	protected void merge(SVNEntryReference reference1, SVNEntryRevisionReference reference2, SVNRevisionRange []revisions, String mergePath, SVNMergeStatus[] mergeStatus, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			for (int i = 0; i < mergeStatus.length && !monitor.isActivityCancelled(); i++) {
				//TODO recordOnly does not work for deletions and additions. Is it right?
				File localFile = new File(mergeStatus[i].path);
				if (mergeStatus[i].textStatus == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.DELETED) {
					this.client.remove(new String[] {mergeStatus[i].path}, null, (options & Options.FORCE) != 0, false, null);
				}
				else if (mergeStatus[i].textStatus == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.ADDED || 
						 mergeStatus[i].textStatus == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED && ((options & ISVNConnector.Options.FORCE) != 0 || !localFile.exists()) ||
						 mergeStatus[i].textStatus == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.CONFLICTED && (options & ISVNConnector.Options.FORCE) != 0) {
					if (localFile.exists()) {
						localFile.delete();// do not perform node replacement, just replace node content
					}
					for (File parent = localFile.getParentFile(); !parent.exists() && parent.getParentFile() != null; ) {
						File tmp = parent.getParentFile();
						if (tmp.exists()) {
							localFile.getParentFile().mkdirs();
							this.client.add(parent.getAbsolutePath(), Depth.INFINITY, true, false, false);
							break;
						}
						parent = tmp;
					}
					CopySource src = new CopySource(mergeStatus[i].endUrl, ConversionUtility.convert(reference2 == null ? (revisions != null ? revisions[revisions.length - 1].to : reference1.pegRevision) : reference2.revision), ConversionUtility.convert(reference2 == null ? reference1.pegRevision : reference2.pegRevision));
					File tmp = File.createTempFile("mergeCopyTarget", ".tmp", localFile.getParentFile());
					tmp.delete();
					this.client.copy(new CopySource[] {src}, tmp.getAbsolutePath(), null, true, false, null);
					
					final Map []data = new Map[1];
					this.client.properties(tmp.getAbsolutePath(), null, null, Depth.EMPTY, null, new org.tigris.subversion.javahl.ProplistCallback() {
						public void singlePath(String path, Map properties) {
							data[0] = properties;
						}
					});
					
					this.client.revert(tmp.getAbsolutePath(), Depth.INFINITY, null);
					tmp.renameTo(new File(mergeStatus[i].path));
					try {
						this.client.add(mergeStatus[i].path, Depth.INFINITY, true, false, false);
					}
					catch (ClientException ex) {
						//could be thrown if node already added
					}
					if (data[0] != null) {
						for (Iterator it = data[0].entrySet().iterator(); it.hasNext(); ) {
							Map.Entry entry = (Map.Entry)it.next();
							this.client.propertySet(mergeStatus[i].path, (String)entry.getKey(), (String)entry.getValue(), Depth.EMPTY, null, false, null);
						}
					}
				}
				else if (reference2 != null) {
					this.client.merge(mergeStatus[i].startUrl, ConversionUtility.convert(((SVNEntryRevisionReference)reference1).revision), mergeStatus[i].endUrl, ConversionUtility.convert(reference2.revision), mergeStatus[i].path, (options & Options.FORCE) != 0, Depth.FILES, (options & Options.IGNORE_ANCESTRY) != 0, false, (options & Options.RECORD_ONLY) != 0);
				}
				else if (revisions != null) {
					this.client.merge(mergeStatus[i].endUrl, ConversionUtility.convert(reference1.pegRevision), ConversionUtility.convert(revisions), mergeStatus[i].path, (options & Options.FORCE) != 0, Depth.FILES, (options & Options.IGNORE_ANCESTRY) != 0, false, (options & Options.RECORD_ONLY) != 0);
				}
				else {
					this.client.mergeReintegrate(mergeStatus[i].endUrl, ConversionUtility.convert(reference1.pegRevision), mergeStatus[i].path, false);
				}
			}
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		catch (IOException e) {
			throw new SVNConnectorException(e);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	protected void mergeStatus(SVNEntryReference reference1, SVNEntryRevisionReference reference2, SVNRevisionRange []revisions, String path, int depth, long options, ISVNMergeStatusCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		final ArrayList<SVNNotification> tmp = new ArrayList<SVNNotification>();
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor) {
			public void notify(SVNNotification arg0) {
				super.notify(arg0);
				tmp.add(arg0);
			}
		};
		try {
			this.composite.add(wrapper);
			wrapper.start();
			
			if (reference2 != null) {
				this.client.merge(reference1.path, ConversionUtility.convert(((SVNEntryRevisionReference)reference1).revision), reference2.path, ConversionUtility.convert(reference2.revision), path, (options & Options.FORCE) != 0, depth, (options & Options.IGNORE_ANCESTRY) != 0, (options & Options.SIMULATE) != 0, (options & Options.RECORD_ONLY) != 0);
			}
			else if (revisions != null) {
				this.client.merge(reference1.path, ConversionUtility.convert(reference1.pegRevision), ConversionUtility.convert(revisions), path, (options & Options.FORCE) != 0, depth, (options & Options.IGNORE_ANCESTRY) != 0, (options & Options.SIMULATE) != 0, (options & Options.RECORD_ONLY) != 0);
			}
			else {
				this.client.mergeReintegrate(reference1.path, ConversionUtility.convert(reference1.pegRevision), path, (options & Options.SIMULATE) != 0);
			}
			
			SVNRevision from = reference2 == null ? (revisions != null ? revisions[0].from : SVNRevision.fromNumber(1)) : ((SVNEntryRevisionReference)reference1).revision;
			SVNRevision to = reference2 == null ? (revisions != null ? revisions[revisions.length - 1].to : reference1.pegRevision) : reference2.revision;
			if (from.getKind() != SVNRevision.Kind.NUMBER) {
				SVNLogEntry []entries = SVNUtility.logEntries(this, reference1, from, SVNRevision.fromNumber(1), ISVNConnector.Options.NONE, ISVNConnector.EMPTY_LOG_ENTRY_PROPS, 1, monitor);
				from = SVNRevision.fromNumber(entries[0].revision);
			}
			if (to.getKind() != SVNRevision.Kind.NUMBER) {
				SVNLogEntry []entries = SVNUtility.logEntries(this, reference2 == null ? reference1 : reference2, to, SVNRevision.fromNumber(1), ISVNConnector.Options.NONE, ISVNConnector.EMPTY_LOG_ENTRY_PROPS, 1, monitor);
				to = SVNRevision.fromNumber(entries[0].revision);
			}
			//tag creation revision greater than last changed revision of CopiedFromURL
			if (reference2 != null) {
				if (from.equals(to)) {
					from = SVNRevision.fromNumber(((SVNRevision.Number)to).getNumber() - 1);
				}
			}
			boolean reversed =
				reference2 == null ? 
				SVNUtility.compareRevisions(from, to, new SVNEntryRevisionReference(reference1.path, reference1.pegRevision, from), new SVNEntryRevisionReference(reference1.path, reference1.pegRevision, to), this) == 1 :
				SVNUtility.compareRevisions(from, to, (SVNEntryRevisionReference)reference1, reference2, this) == 1;
			
			int i = 0;
			String startUrlPref = reference1.path;
			String endUrlPref = reference2 == null ? reference1.path : reference2.path;
			SVNLogEntry []allMsgs = 
				reversed ? 
				SVNUtility.logEntries(this, reference2 == null ? reference1 : this.getValidReference(reference2, from, monitor), from, to, ISVNConnector.Options.DISCOVER_PATHS, ISVNConnector.DEFAULT_LOG_ENTRY_PROPS, 0, monitor) : 
				SVNUtility.logEntries(this, reference2 == null ? reference1 : reference2, to, from, ISVNConnector.Options.DISCOVER_PATHS, ISVNConnector.DEFAULT_LOG_ENTRY_PROPS, 0, monitor);
			long minRev = ((SVNRevision.Number)(reversed ? to : from)).getNumber();
			for (Iterator<SVNNotification> it = tmp.iterator(); it.hasNext() && !monitor.isActivityCancelled(); i++) {
				SVNNotification state = it.next();
				
				String tPath = state.path.substring(path.length());
				String startUrl = SVNUtility.normalizeURL(startUrlPref + tPath);
				String endUrl = SVNUtility.normalizeURL(endUrlPref + tPath);
				boolean skipped = state.action == org.eclipse.team.svn.core.connector.SVNNotification.PerformedAction.SKIP;
				
				int cState = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NONE;
				int pState = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NONE;
				if (state.action == org.eclipse.team.svn.core.connector.SVNNotification.PerformedAction.UPDATE_ADD) {
					cState = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.ADDED;
				}
				else if (state.action == org.eclipse.team.svn.core.connector.SVNNotification.PerformedAction.UPDATE_DELETE) {
					cState = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.DELETED;
				}
				else if (state.action == org.eclipse.team.svn.core.connector.SVNNotification.PerformedAction.UPDATE_UPDATE) {
					pState = state.propState == org.eclipse.team.svn.core.connector.SVNNotification.NodeStatus.CHANGED ? org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED :
								(state.propState == org.eclipse.team.svn.core.connector.SVNNotification.NodeStatus.CONFLICTED ? 
								org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.CONFLICTED : 
								org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NONE);
					cState = 
						(state.contentState == org.eclipse.team.svn.core.connector.SVNNotification.NodeStatus.CHANGED || state.contentState == org.eclipse.team.svn.core.connector.SVNNotification.NodeStatus.MERGED) ? 
								org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED : 
								(state.contentState == org.eclipse.team.svn.core.connector.SVNNotification.NodeStatus.CONFLICTED ? 
								org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.CONFLICTED : 
								org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NONE);
				}
				else if (state.action == org.eclipse.team.svn.core.connector.SVNNotification.PerformedAction.SKIP) {
					if (state.contentState == org.eclipse.team.svn.core.connector.SVNNotification.NodeStatus.MISSING) {
						try {
							SVNRevision pegRev = reference1.pegRevision;
							if (reference2 != null) {
								pegRev = reference2.pegRevision;
							}
							SVNUtility.info(this, new SVNEntryRevisionReference(endUrl, pegRev, to), ISVNConnector.Depth.EMPTY, monitor);
							pState = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED;
							cState = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED;
						}
						catch (Exception ex) {
							cState = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.DELETED;
						}
					}
					else if (state.contentState == org.eclipse.team.svn.core.connector.SVNNotification.NodeStatus.OBSTRUCTED) {
						cState = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.ADDED;
					}
				}
				
				if (cState != org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NONE || pState != org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NONE) {
					long startRevision = SVNRevision.INVALID_REVISION_NUMBER;
					long endRevision = SVNRevision.INVALID_REVISION_NUMBER;
					long date = 0;
					String author = null;
					String message = null;
					monitor.progress(i, tmp.size(), JavaHLConnector.makeItemState(state));
					if (cState == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.ADDED && !reversed || 
						cState == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.DELETED && reversed) {
						int idx = this.getLogIndex(allMsgs, endUrl, false);
						if (idx != -1) {
							endRevision = allMsgs[idx].revision;
							date = allMsgs[idx].date;
							author = allMsgs[idx].author;
							message = allMsgs[idx].message;
						}
					}
					else if (cState == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED || cState == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.CONFLICTED || 
							pState == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED ||  pState == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.CONFLICTED) {
						int idx = this.getLogIndex(allMsgs, endUrl, false);
						if (idx != -1) {
							endRevision = allMsgs[idx].revision;
							date = allMsgs[idx].date;
							author = allMsgs[idx].author;
							message = allMsgs[idx].message;
						}
						idx = this.getLogIndex(allMsgs, startUrl, true);
						startRevision = idx != -1 ? Math.max(allMsgs[idx].revision, minRev) : minRev;
					}
					else {
						int idx = this.getLogIndex(allMsgs, endUrl, false);
						if (idx != -1) {
							endRevision = allMsgs[idx].revision;
							date = allMsgs[idx].date;
							author = allMsgs[idx].author;
							message = allMsgs[idx].message;
						}
						else {
							idx = this.getLogIndex(allMsgs, startUrl, false);
							if (idx != -1) {
								endUrl = startUrl;
								endRevision = allMsgs[idx].revision;
								date = allMsgs[idx].date;
								author = allMsgs[idx].author;
								message = allMsgs[idx].message;
							}
						}
						idx = this.getLogIndex(allMsgs, startUrl, true);
						startRevision = idx != -1 ? Math.max(allMsgs[idx].revision, minRev) : minRev;
					}
					if (reversed) {
						startRevision = endRevision;
						endRevision = allMsgs[allMsgs.length - 1].revision;
						date = allMsgs[allMsgs.length - 1].date;
						author = allMsgs[allMsgs.length - 1].author;
						message = allMsgs[allMsgs.length - 1].message;
					}
					cb.next(new SVNMergeStatus(startUrl, endUrl, state.path, state.kind, cState, pState, startRevision, endRevision, date, author, message, skipped, false, null));
				}
			}
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	protected SVNEntryReference getValidReference(SVNEntryReference referenceToExisting, SVNRevision lastRevision, ISVNProgressMonitor monitor) throws SVNConnectorException{
		if (referenceToExisting.pegRevision.getKind() != SVNRevision.Kind.HEAD &&
			referenceToExisting.pegRevision.getKind() != SVNRevision.Kind.NUMBER) {
			throw new RuntimeException("Unexpected revision kind. Kind: " + referenceToExisting.pegRevision.getKind());
		}
		if (lastRevision.getKind() != SVNRevision.Kind.NUMBER) {
			throw new RuntimeException("Unexpected last revision kind. Kind: " + lastRevision.getKind());
		}
			
		if (referenceToExisting.pegRevision.getKind() == SVNRevision.Kind.HEAD) {
			return referenceToExisting;
		}
			
		long start = ((SVNRevision.Number)referenceToExisting.pegRevision).getNumber();
		long end = ((SVNRevision.Number)lastRevision).getNumber();
		while (end > start) {
			referenceToExisting = this.getLastValidReference(referenceToExisting, lastRevision, monitor);
			if (!referenceToExisting.pegRevision.equals(lastRevision)) {
				start = ((SVNRevision.Number)referenceToExisting.pegRevision).getNumber() + 1;
				SVNEntryReference tRef = new SVNEntryReference(referenceToExisting.path, SVNRevision.fromNumber(start));
				while (!this.exists(tRef, monitor)) {
					tRef = new SVNEntryReference(tRef.path.substring(0, tRef.path.lastIndexOf("/")), tRef.pegRevision);
				}
				SVNLogEntry []log = SVNUtility.logEntries(this, tRef, tRef.pegRevision, referenceToExisting.pegRevision, ISVNConnector.Options.DISCOVER_PATHS, ISVNConnector.DEFAULT_LOG_ENTRY_PROPS, 0, monitor);
				SVNLogPath []paths = log[0].changedPaths;
				boolean renamed = false;
				if (paths != null) {
					String decodedUrl = SVNUtility.decodeURL(referenceToExisting.path);
					for (int k = 0; k < paths.length; k++) {
						if (paths[k].copiedFromPath != null) {
							int idx = decodedUrl.indexOf(paths[k].copiedFromPath);
							if (idx != -1 && (decodedUrl.charAt(idx + paths[k].copiedFromPath.length()) == '/' || decodedUrl.endsWith(paths[k].copiedFromPath))) {
								decodedUrl = decodedUrl.substring(0, idx) + paths[k].path + decodedUrl.substring(idx + paths[k].copiedFromPath.length());
								tRef = new SVNEntryReference(SVNUtility.encodeURL(decodedUrl), tRef.pegRevision);
								renamed = true;
								break;
							}
						}
					}
				}
				referenceToExisting = tRef;
				if (!renamed) {
					return referenceToExisting;
				}
			}
		} 
		return referenceToExisting;
	}
	
	protected SVNEntryReference getLastValidReference(SVNEntryReference referenceToExisting, SVNRevision lastRevision, ISVNProgressMonitor monitor) {
		long start = ((SVNRevision.Number)referenceToExisting.pegRevision).getNumber();
		long end = ((SVNRevision.Number)lastRevision).getNumber();
		do {
			long middle = end - (end - start) / 2; //long is largest type and (end + start) could out of type ranges
			SVNEntryReference tRef = new SVNEntryReference(referenceToExisting.path, SVNRevision.fromNumber(middle));
			if (this.exists(tRef, monitor)) {
				start = middle;
				referenceToExisting = tRef;
			}
			else {
				if (end - start == 1) {
					break;
				}
				end = middle;
			}
		} 
		while (end > start);
		return referenceToExisting;
	}
	
	protected boolean exists(SVNEntryReference reference, ISVNProgressMonitor monitor) {
		try {
			SVNUtility.logEntries(this, reference, reference.pegRevision, reference.pegRevision, ISVNConnector.Options.NONE, ISVNConnector.EMPTY_LOG_ENTRY_PROPS, 1, monitor);
			return true;
		}
		catch (SVNConnectorException e) {
			return false;
		}
	}
	
	protected int getLogIndex(SVNLogEntry []msgs, String url, boolean last) {
		String decodedUrl = SVNUtility.decodeURL(url);
		int retVal = -1;
		for (int j = 0; j < msgs.length; j++) {
			SVNLogPath []paths = msgs[j].changedPaths;
			if (paths != null) {
				int maxPathIdx = -1, maxPathLen = 0;
				for (int k = 0; k < paths.length; k++) {
					if (paths[k] != null && decodedUrl.endsWith(paths[k].path)) {
						if (last) {
							if (paths[k].copiedFromPath != null) {
								maxPathIdx = k;
								maxPathLen = paths[k].path.length();
							}
							retVal = paths[k].action == SVNLogPath.ChangeType.ADDED ? j : -1;
						}
						else {
							return j;
						}
					}
					else if (paths[k].copiedFromPath != null) {
						int idx = decodedUrl.indexOf(paths[k].path);
						if (idx != -1 && (decodedUrl.charAt(idx + paths[k].path.length()) == '/' || decodedUrl.endsWith(paths[k].path)) && paths[k].path.length() > maxPathLen) {
							maxPathIdx = k;
							maxPathLen = paths[k].path.length();
						}
					}
				}
				if (maxPathIdx != -1) {
					int idx = decodedUrl.indexOf(paths[maxPathIdx].path);
					decodedUrl = decodedUrl.substring(0, idx) + paths[maxPathIdx].copiedFromPath + decodedUrl.substring(idx + paths[maxPathIdx].path.length());
				}
			}
		}
		return retVal;
	}


	public void doImport(String path, String url, String message, int depth, long options, Map revProps, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.doImport(path, url, message, depth, (options & Options.INCLUDE_IGNORED) != 0, (options & Options.IGNORE_UNKNOWN_NODE_TYPES) != 0, ConversionUtility.convert(revProps));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public long doExport(SVNEntryRevisionReference fromReference, String destPath, String nativeEOL, int depth, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			return this.client.doExport(fromReference.path, destPath, ConversionUtility.convert(fromReference.revision), ConversionUtility.convert(fromReference.pegRevision), (options & Options.FORCE) != 0, (options & Options.IGNORE_EXTERNALS) != 0, depth, nativeEOL);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return 0;
	}

	public void diff(SVNEntryRevisionReference reference1, SVNEntryRevisionReference reference2, String relativeToDir, String outFileName, int depth, long options, String[] changelistNames, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.diff(reference1.path, ConversionUtility.convert(reference1.revision), reference2.path, ConversionUtility.convert(reference2.revision), relativeToDir, outFileName, depth, changelistNames, (options & Options.IGNORE_ANCESTRY) != 0, (options & Options.SKIP_DELETED) != 0, (options & Options.FORCE) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void diff(SVNEntryReference reference, SVNRevision revision1, SVNRevision revision2, String relativeToDir, String outFileName, int depth, long options, String[] changelistNames, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.diff(reference.path, ConversionUtility.convert(reference.pegRevision), ConversionUtility.convert(revision1), ConversionUtility.convert(revision2), relativeToDir, outFileName, depth, changelistNames, (options & Options.IGNORE_ANCESTRY) != 0, (options & Options.SKIP_DELETED) != 0, (options & Options.FORCE) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public void diffStatus(SVNEntryRevisionReference reference1, SVNEntryRevisionReference reference2, int depth, long options, String[] changelistNames, ISVNDiffStatusCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		SVNEntryInfo []infos = SVNUtility.info(this, reference1, Depth.EMPTY, monitor);
		boolean isFile = infos.length > 0 && infos[0] != null && infos[0].kind == SVNEntry.Kind.FILE;
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			
			DiffCallback callback = new DiffCallback(reference1.path, reference2.path, isFile, cb);
			this.client.diffSummarize(reference1.path, ConversionUtility.convert(reference1.revision), reference2.path, ConversionUtility.convert(reference2.revision), depth, changelistNames, (options & Options.IGNORE_ANCESTRY) != 0, callback);
			callback.doLastDiff();
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void diffStatus(SVNEntryReference reference, SVNRevision revision1, SVNRevision revision2, int depth, long options, String[] changelistNames, ISVNDiffStatusCallback cb, final ISVNProgressMonitor monitor) throws SVNConnectorException {
		SVNEntryInfo []infos = SVNUtility.info(this, new SVNEntryRevisionReference(reference, revision1), Depth.EMPTY, monitor);
		boolean isFile = infos.length > 0 && infos[0] != null && infos[0].kind == SVNEntry.Kind.FILE;
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			
			DiffCallback callback = new DiffCallback(reference.path, reference.path, isFile, cb);
			this.client.diffSummarize(reference.path, ConversionUtility.convert(reference.pegRevision), ConversionUtility.convert(revision1), ConversionUtility.convert(revision2), depth, changelistNames, (options & Options.IGNORE_ANCESTRY) != 0, callback);
			callback.doLastDiff();
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void info(SVNEntryRevisionReference reference, int depth, String[] changelistNames, ISVNEntryInfoCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.info2(reference.path, ConversionUtility.convert(reference.revision), ConversionUtility.convert(reference.pegRevision), depth, changelistNames, ConversionUtility.convert(cb));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void streamFileContent(SVNEntryRevisionReference reference, int bufferSize, OutputStream stream, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.streamFileContent(reference.path, ConversionUtility.convert(reference.revision), ConversionUtility.convert(reference.pegRevision), bufferSize, stream);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public void mkdir(String []path, String message, long options, Map revProps, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.mkdir(path, message, (options & Options.INCLUDE_PARENTS) != 0, ConversionUtility.convert(revProps));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void move(String[] srcPaths, String dstPath, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.move(srcPaths, dstPath, null, (options & Options.FORCE) != 0, true, false, null);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void move(SVNEntryReference[]srcPaths, String dstPath, String message, long options, Map revProps, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			ArrayList<String> src = new ArrayList<String>();
			for (SVNEntryReference current : srcPaths) {
				src.add(current.path);
			}
			this.client.move(src.toArray(new String[0]), dstPath, message == null ? "" : message, (options & Options.FORCE) != 0, (options & Options.INTERPRET_AS_CHILD) != 0, (options & Options.INCLUDE_PARENTS) != 0, ConversionUtility.convert(revProps));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void copy(String[] srcPaths, String destPath, SVNRevision revision, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			CopySource []srcs = new CopySource[srcPaths.length];
			for (int i = 0; i < srcPaths.length; i++) {
				srcs[i] = new CopySource(srcPaths[i], ConversionUtility.convert(revision), null);
			}
			this.client.copy(srcs, destPath, null, true, false, null);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public void copy(SVNEntryRevisionReference []srcPaths, String destPath, String message, long options, Map revProps, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.copy(ConversionUtility.convert(srcPaths), destPath, message == null ? "" : message, (options & Options.INTERPRET_AS_CHILD) != 0, (options & Options.INCLUDE_PARENTS) != 0, ConversionUtility.convert(revProps));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public void remove(String []path, String message, long options, Map revProps, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.remove(path, message == null ? "" : message, (options & Options.FORCE) != 0, (options & Options.KEEP_LOCAL) != 0, ConversionUtility.convert(revProps));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void logEntries(SVNEntryReference reference, SVNRevisionRange []revisionRanges, String[] revProps, long limit, long options, ISVNLogEntryCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			if (revProps == null) {
				// prevent the access violation in the svnjavahl library
				throw new NullPointerException("revProps argument cannot be null");
			}
			LogMessageCallback cb_ = ConversionUtility.convert(cb);
			Revision pRev = ConversionUtility.convert(reference.pegRevision);
			for (SVNRevisionRange range : revisionRanges) {
				this.client.logMessages(reference.path, pRev, ConversionUtility.convert(range.from), ConversionUtility.convert(range.to), (options & Options.STOP_ON_COPY) != 0, (options & Options.DISCOVER_PATHS) != 0, (options & Options.INCLUDE_MERGED_REVISIONS) != 0, revProps, limit, cb_);
			}
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void annotate(SVNEntryReference reference, SVNRevision revisionStart, SVNRevision revisionEnd, long options, ISVNAnnotationCallback callback, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.blame(reference.path, ConversionUtility.convert(reference.pegRevision), ConversionUtility.convert(revisionStart), ConversionUtility.convert(revisionEnd), (options & Options.IGNORE_MIME_TYPE) != 0, (options & Options.INCLUDE_MERGED_REVISIONS) != 0, ConversionUtility.convert(callback));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void list(SVNEntryRevisionReference reference, int depth, int direntFields, long options, final ISVNEntryCallback cb, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.list(reference.path, ConversionUtility.convert(reference.revision), ConversionUtility.convert(reference.pegRevision), depth, direntFields, (options & Options.FETCH_LOCKS) != 0, new ListCallback() {
				public void doEntry(org.tigris.subversion.javahl.DirEntry dirent, Lock lock) {
					String path = dirent.getPath();
					if (path != null && path.length() != 0 || dirent.getNodeKind() == org.tigris.subversion.javahl.NodeKind.file) {
						Date date = dirent.getLastChanged();
						cb.next(new SVNEntry(path, dirent.getLastChangedRevisionNumber(), date == null ? 0 : date.getTime(), dirent.getLastAuthor(), dirent.getHasProps(), dirent.getNodeKind(), dirent.getSize(), ConversionUtility.convert(lock)));
					}
				}
			});
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void getProperties(SVNEntryRevisionReference reference, int depth, String[] changelistNames, ISVNPropertyCallback callback, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.properties(reference.path, ConversionUtility.convert(reference.revision), ConversionUtility.convert(reference.pegRevision), depth, changelistNames, ConversionUtility.convert(callback));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public SVNProperty getProperty(SVNEntryRevisionReference reference, String name, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			return ConversionUtility.convert(this.client.propertyGet(reference.path, name, ConversionUtility.convert(reference.revision), ConversionUtility.convert(reference.pegRevision)));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return null;
	}

	public void removeProperty(String path, String name, int depth, String[] changelistNames, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.propertyRemove(path, name, depth, changelistNames);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public void setProperty(String path, String name, String value, int depth, long options, String[] changelistNames, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.propertySet(path, name, value, depth, changelistNames, (options & Options.FORCE) != 0, null);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}

	public SVNProperty []getRevisionProperties(SVNEntryReference reference, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			
			return ConversionUtility.convert(this.client.revProperties(reference.path, ConversionUtility.convert(reference.pegRevision)));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return null;
	}

	public SVNProperty getRevisionProperty(SVNEntryReference reference, String name, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			return ConversionUtility.convert(this.client.revProperty(reference.path, name, ConversionUtility.convert(reference.pegRevision)));
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
		// unreachable code
		return null;
	}

	public void setRevisionProperty(SVNEntryReference reference, String name, String value, String originalValue, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			this.client.setRevProperty(reference.path, name, ConversionUtility.convert(reference.pegRevision), value, (options & Options.FORCE) != 0);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}
	}
	
	public void removeRevisionProperty(SVNEntryReference reference, String name, long options, ISVNProgressMonitor monitor) throws SVNConnectorException {
		
	}

	public void dispose() {
		this.client.dispose();
		this.svnAdmin.dispose();
	}

	protected void handleSubversionException(SubversionException ex) throws SVNConnectorException {
		throw new SVNConnectorException(ConversionUtility.convertZeroCodedLine(ex.getMessage()), ex);
	}
	
	protected void handleClientException(ClientException ex) throws SVNConnectorException {
		String msg = ConversionUtility.convertZeroCodedLine(ex.getMessage());
		if (this.findConflict(ex)) {
			throw new SVNConnectorUnresolvedConflictException(msg, ex);
		}
		if (this.findCancel(ex)) {
			throw new SVNConnectorCancelException(msg, ex);
		}
		if (this.findAuthentication(ex)) {
			throw new SVNConnectorAuthenticationException(msg, ex);
		}
		throw new SVNConnectorException(msg, ex.getAprError(), ex);
	}
	
	protected boolean findConflict(ClientException t) {
    	return t.getAprError() == SVNErrorCodes.fsConflict || t.getAprError() == SVNErrorCodes.fsTxnOutOfDate;
	}
    
	protected boolean findAuthentication(ClientException t) {
    	return t.getAprError() == SVNErrorCodes.raNotAuthorized;
	}
    
	protected boolean findCancel(ClientException t) {
    	return t.getAprError() == SVNErrorCodes.cancelled;
	}
	
	public static ISVNProgressMonitor.ItemState makeItemState(SVNNotification arg0) {
		return new ISVNProgressMonitor.ItemState(arg0.path, arg0.action, arg0.kind, arg0.mimeType, arg0.contentState, arg0.propState, arg0.revision);
	}
	
	private class DiffCallback implements DiffSummaryReceiver {
		private String prev;
		private String next;
		private boolean isFile;
		private SVNDiffStatus savedDiff;
		private ISVNDiffStatusCallback cb;
		
		public DiffCallback(String prev, String next, boolean isFile, ISVNDiffStatusCallback cb) {
			this.prev = SVNUtility.decodeURL(prev);
			this.next = SVNUtility.decodeURL(next);
			this.isFile = isFile;
			this.cb = cb;
		}
		
		public void onSummary(DiffSummary descriptor) {
			int changeType = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NORMAL;
			if (descriptor.getDiffKind() == DiffSummary.DiffKind.ADDED) {
				changeType = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.ADDED;
			}
			else if (descriptor.getDiffKind() == DiffSummary.DiffKind.DELETED) {
				changeType = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.DELETED;
			}
			else if (descriptor.getDiffKind() == DiffSummary.DiffKind.MODIFIED) {
				changeType = org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED;
			}
			int propChangeType = descriptor.propsChanged() ? org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.MODIFIED : org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NORMAL;
			if (changeType != org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NORMAL || propChangeType != org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NORMAL) {
				String tPath1 = descriptor.getPath();
				String tPath2 = tPath1;
				if (tPath1.length() == 0 || this.isFile) {
					tPath1 = this.prev;
					tPath2 = this.next;
				}
				else {
					tPath1 = this.prev + "/" + tPath1;
					tPath2 = this.next + "/" + tPath2;
				}
				SVNDiffStatus status = new SVNDiffStatus(SVNUtility.encodeURL(tPath1), SVNUtility.encodeURL(tPath2), descriptor.getNodeKind(), changeType, propChangeType);
				if (this.savedDiff != null) {
					if (this.savedDiff.pathPrev.equals(status.pathPrev) && this.savedDiff.pathNext.equals(status.pathNext) && 
						this.savedDiff.textStatus == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.DELETED &&
						status.textStatus == org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.ADDED) {
						this.savedDiff = new SVNDiffStatus(SVNUtility.encodeURL(tPath1), SVNUtility.encodeURL(tPath2), descriptor.getNodeKind(), org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.REPLACED, org.eclipse.team.svn.core.connector.SVNEntryStatus.Kind.NORMAL);
						status = null;
					}
					this.cb.next(this.savedDiff);
				}
				this.savedDiff = status;
			}
		}
		
		public void doLastDiff() {
			if (this.savedDiff != null) {
				this.cb.next(this.savedDiff);
			}
		}
	}

	protected synchronized static ProgressMonitorThread getProgressMonitorThread() {
		if (JavaHLConnector.monitorWrapperThread == null) {
			JavaHLConnector.monitorWrapperThread = new ProgressMonitorThread();
			JavaHLConnector.monitorWrapperThread.start();
		}
		return JavaHLConnector.monitorWrapperThread;
	}
	
	protected static class ProgressMonitorThread extends Thread {
		private final List<ProgressMonitorWrapper> monitors = new ArrayList<ProgressMonitorWrapper>();

		public ProgressMonitorThread() {
			super("JavaHL 1.5 Connector");
		}

		public void add(ProgressMonitorWrapper monitor) {
			synchronized (this.monitors) {
				this.monitors.add(monitor);
				this.monitors.notify();
			}
		}
		
		public void remove(ProgressMonitorWrapper monitor) {
			synchronized (this.monitors) {
				this.monitors.remove(monitor);
			}
		}
		
		public void run() {
			synchronized (this.monitors) {
				while (!this.isInterrupted()) {
					this.checkForActivityCancelled();
					
					try {
						if (this.monitors.size() == 0) {
							this.monitors.wait();
						}
						else {
							this.monitors.wait(100);
						}
					}
					catch (InterruptedException ex) {
						break;
					}
				}
			}
		}

		private void checkForActivityCancelled() {
			for (ProgressMonitorWrapper monitor : this.monitors) {
				if (monitor.monitor.isActivityCancelled()) {
					monitor.cancel();
				}
			}
		}

	}
	
	protected class ProgressMonitorWrapper implements ISVNNotificationCallback {
		protected ISVNProgressMonitor monitor;
		protected int current;
		protected String errorMessage;

		public ProgressMonitorWrapper(ISVNProgressMonitor monitor) {
			this.monitor = monitor;
			this.current = 0;
		}

		public void cancel() {
			try {
				JavaHLConnector.this.client.cancelOperation();
			}
			catch (Exception e) {
			}
		}

		public String getErrorMessage() {
			return this.errorMessage;
		}

		public void notify(SVNNotification arg0) {
			if (arg0.errMsg != null) {
				this.errorMessage = this.errorMessage == null ? arg0.errMsg : (this.errorMessage + "\n\n" + arg0.errMsg);
				this.monitor.reportError(arg0.errMsg);
			}
			else {
				this.monitor.progress(this.current++, ISVNProgressMonitor.TOTAL_UNKNOWN, JavaHLConnector.makeItemState(arg0));
			}
		}

		public void start() {
			JavaHLConnector.getProgressMonitorThread().add(this);
		}

		public void interrupt() {
			JavaHLConnector.getProgressMonitorThread().remove(this);
		}

	}
    
	protected class RepositoryInfoPrompt implements PromptUserPassword3 {
		protected ISVNCredentialsPrompt prompt;
		
		public RepositoryInfoPrompt(ISVNCredentialsPrompt prompt) {
			this.prompt = prompt;
		}

	    public boolean prompt(String realm, String username) {
	        return this.prompt.prompt(null, realm);
		}
		
	    public boolean prompt(String realm, String username, boolean maySave) {
	        return this.prompt.prompt(null, realm);
		}

	    public int askTrustSSLServer(String info, boolean allowPermanently) {
	    	return this.prompt.askTrustSSLServer(null, info, allowPermanently);
		}

	    public String getUsername() {
	        return this.prompt.getUsername();
	    }
	    
	    public String getPassword() {
	        return this.prompt.getPassword();
	    }
	    
	    public boolean askYesNo(String realm, String question, boolean yesIsDefault) {
	        return false;
	    }
	    
	    public String askQuestion(String realm, String question, boolean showAnswer, boolean maySave) {
	    	if (question.indexOf("certificate filename") != -1) {
	    		if (JavaHLConnector.this.sslCertificate != null) {
	    			String retVal = JavaHLConnector.this.sslCertificate;
	    			return retVal;
	    		}
	    		else if (!this.prompt.promptSSL(null, realm)) {
		    		return null;
		    	}
	    		else {
	    			JavaHLConnector.this.sslPassphrase = this.prompt.getSSLClientCertPassword();
	    			return this.prompt.getSSLClientCertPath();
	    		}
	    	}
	    	if (question.indexOf("certificate passphrase") != -1) {
	    		if (JavaHLConnector.this.sslPassphrase != null) {
	    			String retVal = JavaHLConnector.this.sslPassphrase;
	    			return retVal;
	    		}
	    		else if (!this.prompt.promptSSL(null, realm)) {
		    		return null;
		    	}
	    		else {
	    			return this.prompt.getSSLClientCertPassword();
	    		}
	    	}
	    	return null;
	    }
	    
	    public String askQuestion(String realm, String question, boolean showAnswer) {
	        return null;
	    }
	    
	    public boolean userAllowedSave() {
	    	return this.prompt.isSaveCredentialsEnabled();
	    }
	    
	}

	public void createRepository(String repositoryPath, String repositoryType, ISVNProgressMonitor monitor) throws SVNConnectorException {
		ProgressMonitorWrapper wrapper = new ProgressMonitorWrapper(monitor);
		try {
			this.composite.add(wrapper);
			wrapper.start();
			
			String fsType = repositoryType == null ? ISVNConnector.REPOSITORY_FSTYPE_FSFS : repositoryType;
			this.svnAdmin.create(repositoryPath, false, false, null, fsType);
		}
		catch (ClientException ex) {
			this.handleClientException(ex);
		}
		finally {
			wrapper.interrupt();
			this.composite.remove(wrapper);
		}    
	}
}
